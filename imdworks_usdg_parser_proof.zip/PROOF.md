# USDG Decimal Parsing Proof

## Scope

Bounty #0009, `Prove exact USDG decimal parsing with generated cases`.

The implementation uses integer micro-units with a fixed six-decimal scale. It does not use floating-point arithmetic for parsing, formatting, or round trips.

## Deliverables

- `parser.py`
  - `parse_amount(text) -> int`
  - `format_amount(units) -> str`
  - independent Decimal oracle used only for cross-checking
- `test_parser.py`
  - hand-selected edge cases
  - 100,000 seeded generated cases
  - independent reference-parser comparison
  - floating-point counterexamples
  - formatter properties

## Grammar

Accepted input is ASCII canonical unsigned decimal text:

```text
^(0|[1-9][0-9]*)(\.[0-9]{1,6})?$
```

Accepted examples include `0`, `1`, `1.2`, and `1.000001`.

Rejected examples include signs, leading zeros, whitespace, exponent notation, grouping separators, Unicode digit lookalikes, and more than six fractional digits. The parser rejects lossy input instead of silently rounding.

## Canonical output

`format_amount` returns the smallest decimal representation that round-trips to the same integer micro-unit value. It uses integer division and remainder only.

Examples:

| Units | Output |
|---:|---:|
| 0 | `0` |
| 1 | `0.000001` |
| 1,200,000 | `1.2` |
| 1,000,001 | `1.000001` |

## Generated test protocol

- PRNG: Python `random.Random`
- Seed: `0x1A2B3C` (`1715004`)
- Cases: `100,000`
- Domain: integer units sampled uniformly from `[0, 10**30)`
- Assertions per case:
  1. integer → canonical string → integer round trip
  2. independent high-precision Decimal oracle agrees

## Hand-selected edge cases

The suite covers zero forms, smallest nonzero unit, six-decimal boundaries, very large values, leading zeros, signs, whitespace, exponent notation, Unicode lookalikes, grouping separators, malformed decimals, and excess precision.

## Floating-point counterexamples

The suite compares exact integer arithmetic against `int(float(text) * 1_000_000)` for values that demonstrate why binary floating point is not acceptable for token amounts. The exact parser remains authoritative.

## Reproduction

```bash
cd /root/imdworks_usdg_parser
python3 test_parser.py
```

Expected output:

```text
PASS: hand edges, 100000 generated cases, float counterexamples, formatter properties
```

## Limitation

This proof validates the parser and formatter locally. It does not claim that an external service or contract uses the same input grammar unless that service specification is supplied separately.

## Integrity

The exact bytes of this file should be hashed after final publication. Any later edit changes the hash.

## Submission status

Local implementation and tests are complete. On-chain submission is intentionally not performed in this document phase. It requires wallet connection, a transaction preview, gas estimate, and explicit confirmation before signing.

## SHA-256

Generate immediately before submission:

```bash
sha256sum PROOF.md
```

Paste the resulting hash into the IMD Works submission form and submit the transaction only after reviewing the chain, contract, bounty ID, gas, and proof URI.
