from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation, localcontext

SCALE = 6
MAX_UNITS = 10**78 - 1
GRAMMAR = re.compile(r"^(0|[1-9][0-9]*)(?:\.([0-9]{1,6}))?$")


def parse_amount(text: str) -> int:
    """Parse canonical unsigned USDG decimal text to integer micro-units.

    Accepted: 0, 1, 1.2, 1.000000. Rejected: signs, whitespace,
    exponents, grouping separators, Unicode digits/lookalikes, and precision > 6.
    """
    if not isinstance(text, str) or not text.isascii():
        raise ValueError("input must be ASCII text")
    m = GRAMMAR.fullmatch(text)
    if not m:
        raise ValueError("invalid USDG amount")
    whole, frac = m.group(1), m.group(2) or ""
    units = int(whole) * 10**SCALE + int(frac.ljust(SCALE, "0") or 0)
    if units > MAX_UNITS:
        raise ValueError("amount exceeds maximum")
    return units


def format_amount(units: int) -> str:
    """Format integer micro-units canonically, without float conversion."""
    if not isinstance(units, int) or isinstance(units, bool) or units < 0:
        raise ValueError("units must be a non-negative integer")
    if units > MAX_UNITS:
        raise ValueError("amount exceeds maximum")
    whole, frac = divmod(units, 10**SCALE)
    if frac == 0:
        return str(whole)
    return f"{whole}.{frac:06d}".rstrip("0")


def reference_parse(text: str) -> int:
    """Independent Decimal-based oracle used only by tests."""
    if not isinstance(text, str) or not text.isascii() or not re.fullmatch(r"^(0|[1-9][0-9]*)(?:\.[0-9]{1,6})?$", text):
        raise ValueError("invalid USDG amount")
    try:
        with localcontext() as ctx:
            ctx.prec = max(128, len(text) + SCALE + 16)
            value = Decimal(text) * Decimal(10**SCALE)
    except InvalidOperation as exc:
        raise ValueError("invalid USDG amount") from exc
    if value != value.to_integral_value():
        raise ValueError("lossy precision")
    return int(value)
