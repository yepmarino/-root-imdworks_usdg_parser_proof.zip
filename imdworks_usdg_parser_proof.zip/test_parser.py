from __future__ import annotations

import random
from decimal import Decimal
from parser import format_amount, parse_amount, reference_parse


def test_hand_edges():
    accepted = {
        "0": 0,
        "0.0": 0,
        "0.000001": 1,
        "1": 1_000_000,
        "1.2": 1_200_000,
        "1.000001": 1_000_001,
        "999999999999999999999999.123456": 999999999999999999999999123456,
    }
    for text, expected in accepted.items():
        assert parse_amount(text) == expected
        assert reference_parse(text) == expected
        assert parse_amount(format_amount(expected)) == expected

    rejected = [
        "", " ", " 1", "1 ", "+1", "-1", "01", "00", "01.2", "1.",
        ".1", "1.1234567", "1e6", "1E-6", "1,2", "１.２", "١.٢", "NaN",
        "Infinity", "1_000", "0x10", "1.0.0", "1\n2", "1\t2",
    ]
    for text in rejected:
        try:
            parse_amount(text)
        except ValueError:
            pass
        else:
            raise AssertionError(f"accepted invalid input {text!r}")


def test_generated_round_trip_and_oracle():
    rng = random.Random(0x1A2B3C)
    for _ in range(100_000):
        units = rng.randrange(0, 10**30)
        text = format_amount(units)
        assert parse_amount(text) == units
        assert reference_parse(text) == units


def test_float_counterexamples():
    cases = ["9007199254.740993", "0.000001", "999999999999.999999"]
    for text in cases:
        exact = parse_amount(text)
        float_units = int(float(text) * 1_000_000)
        assert exact != float_units or text == "0.000001"


def test_formatter_properties():
    rng = random.Random(42)
    for _ in range(1_000):
        units = rng.randrange(0, 10**18)
        out = format_amount(units)
        assert out == out.strip()
        assert "e" not in out.lower()
        assert parse_amount(out) == units
        if "." in out:
            assert len(out.split(".", 1)[1]) <= 6


if __name__ == "__main__":
    test_hand_edges()
    test_generated_round_trip_and_oracle()
    test_float_counterexamples()
    test_formatter_properties()
    print("PASS: hand edges, 100000 generated cases, float counterexamples, formatter properties")
